global.prefa = ['!','.',',','🐤','🗿']

global.owner = ['2348108778025']
global.botname = 'Chucky V5 Beta'
global.baileys1 = require('@whiskeysockets/baileys') 
global.sticker1 = "King Marx"
global.sticker2 = "👑"